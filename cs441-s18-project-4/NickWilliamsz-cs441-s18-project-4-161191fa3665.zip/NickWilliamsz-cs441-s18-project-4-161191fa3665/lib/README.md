# CS441/541
## Project 2 Semaphore Support Library

This directory containst the portable Semaphore Support Library that you will use in your projects. An example of how to use the library is provided in the sum.c/sum.h program.

```
shell$ make
shell$ ./sum
```
